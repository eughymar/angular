angular.module('angularTodo', []);  
function mainController($scope, $http){
	$scope.formData ={};


	$scope.createTodo = function(){
		console.log($scope.formData);
		/*$http.post('/api/todos', $scope.formData)
			.success(function(data){
				$scope.formData ={};
				$scope.todos = data;
				console.log(data);
			})
			.errir(function(data){
				console.log('ERROR: '+ data);
			})*/
	}
}