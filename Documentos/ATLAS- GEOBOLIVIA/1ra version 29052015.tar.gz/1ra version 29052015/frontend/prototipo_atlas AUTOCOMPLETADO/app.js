var App = angular.module('atlas-geo-bo', ['ngDragDrop']);

App.controller('oneCtrl', function($scope, $timeout, $http) {
  $scope.list1 = [{'title': 'Título'},{'title': 'Mapa'},{'title': 'Tabla'}];

  $scope.list2 = [];
  $scope.disenio = true;
  $scope.codigo = false;

  $scope.plantilla = true;
  $scope.plantillaReemplazada = false;

  $scope.formData = {"id":77, "plantilla":""};
  $scope.formDataReemplazado = {};

  $scope.hideMe = function() {
    return $scope.list2.length > 0;
  }

  $scope.habilitarDisenio = function(){
    $scope.disenio = true;
    $scope.codigo = false;
  }

  $scope.habilitarCodigo = function(){
    $scope.disenio = false;
    $scope.codigo = true;
  }
  function reemplazar (key, val) { 
    if (typeof(val)!="string") return val; 
    return val 
    .replace(/[\n]/g, ''); 
  }
  
 $scope.generarHtml = function(){
  //console.log($scope.list2);
  var contenedor = "<html>\n"+
                      "<head>\n"+
                      "<title>PLANTILLA - ATLAS</title>\n"+
                      "</head>\n"+
                      "<body onload=\"init()\">\n";
       
          angular.forEach($scope.list2, function(value, key) {
             
               switch(value.title){
                case 'Título':
                contenedor = contenedor + "<h1>{{titulo}}</h1>";
                break;
                case 'Mapa':
                contenedor = contenedor + "{{mapa}}\n";
                break;
                case 'Tabla':
                contenedor = contenedor + "<div>{{tabla}}</div>\n";
                break;
              }
            });

            contenedor = contenedor + "</body>\n</html>";
            //console.log(contenedor);
            $scope.formData = {"id":100, "plantilla":contenedor};
            //console.log($scope.formData);
          }
    /*Enviando los datos de la plantilla al backend, en respuesta los datos se almacenan en la variable formDataReemplazado*/
    $scope.enviar = function(){
       console.log("Enviando datos");
       console.log(JSON.stringify($scope.formData,reemplazar));

       $http({ 
            headers: {'Content-Type': 'application/json'}, 
            method: 'POST', 
            url: 'http://192.168.3.102:5000/atlas/api/plantilla', 
            data: JSON.stringify($scope.formData,reemplazar)
        }).success(function(response){

           console.log(response);
           console.log(response.id);

           $scope.plantilla = false;
           $scope.plantillaReemplazada = true;

           $scope.formDataReemplazado = {"id":response.id, "plantilla":response.plantilla}
        });
     }


        });

App.filter('unsafe', function($sce) {

  return function(val) {
    return $sce.trustAsHtml(val);
  }
});

App.directive('ngSparkline',function(){
  alert("dddddd");
});